
import React from 'react';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold text-center mb-6">AI Real Estate Assistant</h1>
      <div className="max-w-xl mx-auto bg-white shadow p-6 rounded">
        <p>Welcome to the AI-powered global property platform.</p>
        <p>Ask anything like:</p>
        <ul className="list-disc pl-4 mt-2">
          <li>"Find me a 2-bed in Thailand under £200k"</li>
          <li>"What’s the ROI on this villa in Bali?"</li>
        </ul>
      </div>
    </div>
  );
}

export default App;
