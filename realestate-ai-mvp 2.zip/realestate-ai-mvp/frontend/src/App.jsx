
import React, { useState } from 'react';
import SearchBar from './components/SearchBar';
import Results from './components/Results';
import './App.css';

function App() {
  const [results, setResults] = useState([]);

  const handleSearch = async (query) => {
    const res = await fetch("http://localhost:8000/search?q=" + encodeURIComponent(query));
    const data = await res.json();
    setResults(data.results);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold text-center mb-6">AI Real Estate Assistant</h1>
      <div className="max-w-xl mx-auto">
        <SearchBar onSearch={handleSearch} />
        <Results results={results} />
      </div>
    </div>
  );
}

export default App;
