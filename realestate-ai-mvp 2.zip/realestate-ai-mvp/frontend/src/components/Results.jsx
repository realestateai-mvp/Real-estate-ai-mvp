
import React from 'react';

function Results({ results }) {
  if (!results || results.length === 0) return <p>No results found.</p>;

  return (
    <ul className="space-y-4">
      {results.map((item, index) => (
        <li key={index} className="p-4 bg-white rounded shadow">
          <h3 className="font-bold">{item.title}</h3>
          <p>{item.location} - £{item.price}</p>
        </li>
      ))}
    </ul>
  );
}

export default Results;
