
import React, { useState } from 'react';

function SearchBar({ onSearch }) {
  const [query, setQuery] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch(query);
  };

  return (
    <form onSubmit={handleSubmit} className="mb-6">
      <input
        type="text"
        placeholder="Search properties (e.g. 2-bed in Spain)"
        className="p-2 border rounded w-full"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <button type="submit" className="mt-2 w-full bg-blue-600 text-white py-2 rounded">Search</button>
    </form>
  );
}

export default SearchBar;
