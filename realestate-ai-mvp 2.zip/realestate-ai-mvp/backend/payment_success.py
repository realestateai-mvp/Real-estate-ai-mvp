
from fastapi import APIRouter
from pydantic import BaseModel
import openai
import os

router = APIRouter()

openai.api_key = os.getenv("OPENAI_API_KEY")

class PaidReportRequest(BaseModel):
    location: str
    price: int
    type: str

@router.post("/payment-success-generate-report/")
async def payment_success_generate_report(req: PaidReportRequest):
    prompt = f"Generate a real estate investment report for a {req.type} in {req.location} worth £{req.price}."
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You're an expert real estate investment analyst."},
            {"role": "user", "content": prompt}
        ]
    )
    return {"report": response['choices'][0]['message']['content']}
