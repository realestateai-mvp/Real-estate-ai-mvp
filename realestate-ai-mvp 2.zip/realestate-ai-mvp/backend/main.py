
from fastapi import FastAPI
from pydantic import BaseModel
import openai
import os
from stripe_checkout import router as stripe_router
from payment_success import router as success_router

app = FastAPI()
app.include_router(stripe_router)
app.include_router(success_router)

openai.api_key = os.getenv("OPENAI_API_KEY")

class ReportRequest(BaseModel):
    location: str
    price: int
    type: str

@app.post("/generate-report/")
async def generate_report(req: ReportRequest):
    prompt = f"Generate a real estate investment report for a {req.type} in {req.location} worth £{req.price}."
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You're an expert real estate investment analyst."},
            {"role": "user", "content": prompt}
        ]
    )
    return {"report": response['choices'][0]['message']['content']}
