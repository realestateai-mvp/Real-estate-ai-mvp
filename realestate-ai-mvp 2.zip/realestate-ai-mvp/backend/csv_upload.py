
from fastapi import APIRouter, UploadFile, File
import csv
import os

router = APIRouter()

DATA_PATH = "realestate-ai-mvp/backend/listings.csv"

@router.post("/upload-csv/")
async def upload_csv(file: UploadFile = File(...)):
    contents = await file.read()
    with open(DATA_PATH, "wb") as f:
        f.write(contents)
    return {"message": "CSV uploaded successfully"}
