
import stripe
import os
from fastapi import APIRouter

router = APIRouter()

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

@router.post("/create-checkout-session/")
async def create_checkout_session():
    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{
            'price_data': {
                'currency': 'gbp',
                'product_data': {
                    'name': 'AI Property Investment Report',
                },
                'unit_amount': 1900,
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url='https://yourfrontend.com/success',
        cancel_url='https://yourfrontend.com/cancel',
    )
    return {"id": session.id, "url": session.url}
