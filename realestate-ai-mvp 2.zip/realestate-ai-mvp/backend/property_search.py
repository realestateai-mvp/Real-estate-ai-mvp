
from fastapi import APIRouter, Query
import csv

router = APIRouter()

# Dummy search function using static data
def load_listings():
    return [
        {"title": "2-Bed Condo in Bangkok", "location": "Thailand", "price": 190000},
        {"title": "Beachfront Villa in Bali", "location": "Indonesia", "price": 350000},
        {"title": "Studio in Barcelona", "location": "Spain", "price": 150000},
    ]

@router.get("/search")
async def search_properties(q: str = Query(...)):
    listings = load_listings()
    q_lower = q.lower()
    results = [l for l in listings if q_lower in l["title"].lower() or q_lower in l["location"].lower()]
    return {"results": results}
